Joseph Murche
933289670

My program implements a hash table which is special data type that can store integers as well as strings. I implemented it using dynamic arrays (or I at least tried to).
It looks up values that are associated with keys and stores them in slots on a hash table.

To compile, simply type make into the terminal and then type ./test_ht and it will do it's thing.

Limitations of the program are that it has a low initial capacity and will double each time the load factor becomes to high.